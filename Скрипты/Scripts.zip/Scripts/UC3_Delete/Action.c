Action()
{
	
	lr_start_transaction("UC3_Delete");
	

	WebToursStart();
		
	
	lr_think_time(5);
	

		login();
		
		
	lr_think_time(8);
	
	
	click_itinerary();
	
	
	lr_think_time(10);
	
	
	deleteFirst();
	
	
	lr_think_time(17);
	
	
	
	lr_end_transaction("UC3_Delete", LR_AUTO);


	return 0;
}