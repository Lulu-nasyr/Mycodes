Action()
{
	
	lr_start_transaction("UC4_BookingTickets");

	
		WebToursStart();
	
	lr_think_time(6);
	
		login();
	
	lr_think_time(12);

		click_flights();
	
	lr_think_time(5);
	
		click_find_flights();

	lr_think_time(8);
	
	
	choose_flight();
	
	
		lr_think_time(16);
	
	
	lr_end_transaction("UC4_BookingTickets", LR_AUTO);


	return 0;
}
		