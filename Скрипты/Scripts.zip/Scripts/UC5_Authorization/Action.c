Action()
{

	lr_start_transaction("UC5_Authorization");

		WebToursStart();
	

		lr_think_time(19);
		
		
		login();
	
	
	lr_think_time(10);
	
	
	click_flights();
	
	
	lr_end_transaction("UC5_Authorization", LR_AUTO);


	return 0;
}