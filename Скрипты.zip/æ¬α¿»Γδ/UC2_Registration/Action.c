Action()
{
	
	lr_start_transaction("Registration");
	

	WebToursStart();
	
	
lr_think_time(38);
	
	
	lr_start_transaction("Customer_Profile");
	
	
	//lr_save_string(lr_eval_string("{login}{login}{login}"), "customParam");
	
	
	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	

//</B><BR/>Please choose a username and password combination for your account.<BR/>

	web_reg_find("Text=<BR/>Please choose a username and password combination for your account.<BR/>",LAST);

	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=passwordConfirm", "Value={passwordConfirm}", ENDITEM, 
		"Name=firstName", "Value={firstName}", ENDITEM, 
		"Name=lastName", "Value={lastName}", ENDITEM, 
		"Name=address1", "Value={address1}", ENDITEM, 
		"Name=address2", "Value={address2}", ENDITEM, 
		"Name=register.x", "Value=26", ENDITEM, 
		"Name=register.y", "Value=4", ENDITEM, 
		LAST);

	
	
	lr_end_transaction("Customer_Profile",LR_AUTO);
	
	

	lr_start_transaction("Continue_after_registration");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");
	

	web_url("button_next.gif", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Continue_after_registration",LR_AUTO);
	
	

	lr_end_transaction("Registration", LR_AUTO);

	
	return 0;
}

