Action()
{

lr_start_transaction("UC1_BuyTicket");

	WebToursStart();
	
lr_think_time(25);	
	
	login();
	
lr_think_time(13);

	click_flights();
	
lr_think_time(26);

	click_find_flights();
	

lr_think_time(48);
	
	choose_flight();

	
lr_think_time(19);
	
	fill_payment_detils();	
	
lr_think_time(42);

	click_itinerary();
	
lr_think_time(29);	

	logout();
		
	lr_end_transaction("UC1_BuyTicket", LR_AUTO);
	
	return 0;
}

