Action()
{
	
	lr_start_transaction("UC3_Delete");
	

	WebToursStart();
		
	
	lr_think_time(5);
	

		login();
		
		
	lr_think_time(8);
	
	

	lr_start_transaction("itinerary");
	

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/*Correlation comment - Do not change!  Original value='753-795-JB' Name ='flightID' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=flightID",
		"TagName=input",
		"Extract=value",
		"Name=flightID",
		"Type=hidden",
		"Ordinal=1",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/itinerary.pl*",
		LAST);
		
	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("itinerary",LR_AUTO);
	
	
	lr_start_transaction("delete");
	
	

	web_reg_find("Fail=Found",
		"Text=<b> Flight Details: </b> <BR/>  <center> {departDate} Flight  leaves {arrive}  for {depart}. <br>  </center>",
		LAST);

	web_add_header("Origin", 
		"http://localhost:1080");

	web_submit_form("itinerary.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM,  
		"Name=removeFlights.x", "Value=74", ENDITEM, 
		"Name=removeFlights.y", "Value=9", ENDITEM,
		LAST);		
	
	lr_end_transaction("delete",LR_AUTO);
	
	

	logout ();
	
	
	lr_end_transaction("UC3_Delete", LR_AUTO);


	return 0;
}